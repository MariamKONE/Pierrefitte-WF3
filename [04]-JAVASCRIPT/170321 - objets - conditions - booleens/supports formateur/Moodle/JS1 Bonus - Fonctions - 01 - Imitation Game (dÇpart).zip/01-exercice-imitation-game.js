'use strict';   // Mode strict du JavaScript

/*****************************************************************************/
/* FONCTIONS                                                                 */
/*****************************************************************************/

function letterA()
{
    return "A";
}

function letterB()
{
    return "B";
}

function letterC()
{
    return "C";
}



/*****************************************************************************/
/* CODE PRINCIPAL                                                            */
/*****************************************************************************/

var result;

/*
 * But : il faut utiliser les fonctions écrites au-dessus pour générer les
 * chaînes de caractères affichées à l'écran, en utilisant chaque fois le
 * moins de code possible.
 *
 * La chaîne de caractères sera stockée dans la variable result et cette
 * variable affichée dans la console.
 *
 */

// Code pour la chaîne #1.

// Code pour la chaîne #2.

// Code pour la chaîne #3.

// Code pour la chaîne #4.

// Code pour la chaîne #5.
